## Business Plan
- Ethical donations
- 1% per tx
...