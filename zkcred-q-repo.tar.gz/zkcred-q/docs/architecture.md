## Architecture
- Rust Core
- CLI
- Android App
...